using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using FreeTextBoxControls.Support;

namespace FreeTextBoxControls {
	/// <summary>
	/// DropDownList for the toolbar
	/// </summary>
	public class ToolbarSeparator : ToolbarItem {

	}
}
