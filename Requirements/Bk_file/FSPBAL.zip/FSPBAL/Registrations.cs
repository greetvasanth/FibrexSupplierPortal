﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSPBAL
{
    public class RegSup
    {
        public int RegistrationID { get; set; }
        public string SupplierName { get; set; }
        public string BusinessClass { get; set; }
        public string OwnerName { get; set; }
        public string OfficialEmail { get; set; }
        public string ContactMobile { get; set; }
        public string ContactPhone { get; set; } 
    }
}
